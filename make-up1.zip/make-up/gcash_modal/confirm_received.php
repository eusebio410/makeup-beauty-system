<?php
session_start();
include '../includes/config.php';

// ✅ Ensure user is logged in
if (!isset($_SESSION['user'])) {
    die("❌ No session found. Please log in.");
}

$order_id = $_POST['order_id'] ?? 0;

if (!$order_id) {
    die("❌ Invalid request.");
}

// ✅ Update the order as received
$update = mysqli_query($conn, "
    UPDATE user_orders 
    SET is_received = 1, status = 'completed'
    WHERE id = '$order_id'
");

if ($update) {
    // ✅ Redirect back to user order page
    header("Location:../gcash_modal/user_orders.php");
    exit;
} else {
    die("❌ Failed to update order.");
}
?>
