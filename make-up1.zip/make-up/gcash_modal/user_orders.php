<?php
session_start();
include '../includes/config.php';

// ✅ Ensure user is logged in
if (!isset($_SESSION['user'])) {
    die("<script>alert('❌ No user session found. Please log in.');window.location='login.php';</script>");
}

$user_id = $_SESSION['user']['id'] ?? $_SESSION['user']['user_id'] ?? 0;

// ✅ Fetch user GCash orders from the correct table
$result = mysqli_query($conn, "
    SELECT o.id, p.productName AS product_name, o.quantity, o.total_amount, o.is_received
    FROM user_orders o
    JOIN products p ON o.product_id = p.id
    WHERE o.user_id = '$user_id' AND o.payment_method = 'GCash'
    ORDER BY o.created_at DESC
");
?>

<div class="container mt-5">
    <h3>💳 My GCash Orders</h3>

    <div class="mb-3 text-end">
        <div class="d-flex justify-content-end align-items-center gap-2">
            <!-- Back Button -->
            <a href="../user_modal/user_dashboard.php" class="btn btn-light border">
            ⬅ Back to Home
            </a>

            <!-- Clear Orders Button -->
            <form method="POST" action="clear_all_orders.php" class="m-0">
            <button type="submit" class="btn btn-danger btn-sm"
                onclick="return confirm('Are you sure you want to delete all orders?')">
                Clear All Orders
            </button>
            </form>
        </div>
    </div>


    <table class="table table-striped table-bordered mt-3">
        <thead class="table-dark">
            <tr>
                <th>#</th>
                <th>Product Name</th>
                <th>Quantity</th>
                <th>Total Amount</th>
                <th>Status</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php
            $i = 1;
            if (mysqli_num_rows($result) > 0) {
                while ($row = mysqli_fetch_assoc($result)) {
                    echo "<tr>";
                    echo "<td>{$i}</td>";
                    echo "<td>" . htmlspecialchars($row['product_name']) . "</td>";
                    echo "<td>{$row['quantity']}</td>";
                    echo "<td>₱" . number_format($row['total_amount'], 2) . "</td>";
                    echo "<td>" . ($row['is_received']
                        ? "<span class='badge bg-success'>Received</span>"
                        : "<span class='badge bg-warning text-dark'>Pending</span>") . "</td>";
                    echo "<td>";

                    // ✅ Confirm Received button
                    if (!$row['is_received']) {
                        echo "<form method='POST' action='confirm_received.php' style='display:inline-block;margin-right:5px;'>
                                <input type='hidden' name='order_id' value='{$row['id']}'>
                                <input type='hidden' name='account_type' value='user'>
                                <button type='submit' class='btn btn-success btn-sm'>Confirm Received</button>
                              </form>";
                    }

                    // ✅ Remove Order button
                    echo "<form method='POST' action='remove_order.php' style='display:inline-block;'>
                            <input type='hidden' name='order_id' value='{$row['id']}'>
                            <button type='submit' class='btn btn-danger btn-sm' onclick=\"return confirm('Are you sure to delete this order?')\">Remove</button>
                          </form>";

                    echo "</td></tr>";
                    $i++;
                }
            } else {
                echo "<tr><td colspan='6' class='text-center'>No GCash orders found.</td></tr>";
            }
            ?>
        </tbody>
    </table>
</div>

<!-- ✅ Bootstrap 5 -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
