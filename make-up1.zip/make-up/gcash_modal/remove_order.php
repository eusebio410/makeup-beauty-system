<?php
session_start();
include '../includes/config.php';

// ✅ Ensure user is logged in
if (!isset($_SESSION['user'])) {
    die("<script>alert('❌ No session found. Please log in.');window.location='../login.php';</script>");
}

$account_id = $_SESSION['user']['id'] ?? 0;
$order_id = $_POST['order_id'] ?? 0;

if ($account_id && $order_id) {
    // ✅ Verify the order belongs to this user
    $orderQuery = mysqli_query($conn, "SELECT product_id FROM user_orders WHERE id='$order_id' AND user_id='$account_id'");
    $order = mysqli_fetch_assoc($orderQuery);

    if ($order) {
        // ✅ Delete delivery info first (if any)
        mysqli_query($conn, "DELETE FROM order_delivery WHERE order_id='$order_id'");

        // ✅ Delete the order record
        mysqli_query($conn, "DELETE FROM user_orders WHERE id='$order_id' AND user_id='$account_id'");

        echo "<script>alert('✅ Order removed successfully.');window.location='user_orders.php';</script>";
        exit;
    } else {
        echo "<script>alert('❌ Order not found or does not belong to your account.');window.location='user_orders.php';</script>";
        exit;
    }
}

echo "<script>alert('❌ Invalid request.');window.location='user_orders.php';</script>";
exit;
?>
