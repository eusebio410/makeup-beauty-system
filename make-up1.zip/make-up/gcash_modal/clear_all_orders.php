<?php
session_start();
include '../includes/config.php';

// ✅ Ensure user is logged in
if (!isset($_SESSION['user'])) {
    echo "<script>alert('❌ No session found. Please log in.');window.location='../login.php';</script>";
    exit;
}

$user_id = $_SESSION['user']['id'] ?? 0;

// ✅ Fetch all GCash orders for this user
$ordersQuery = mysqli_query($conn, "
    SELECT id AS order_id 
    FROM user_orders 
    WHERE user_id='$user_id' AND payment_method='GCash'
");

if (mysqli_num_rows($ordersQuery) > 0) {
    while ($order = mysqli_fetch_assoc($ordersQuery)) {
        $order_id = $order['order_id'];

        // ✅ Delete related delivery info first (if exists)
        mysqli_query($conn, "DELETE FROM order_delivery WHERE order_id='$order_id'");

        // ✅ Delete the order itself
        mysqli_query($conn, "DELETE FROM user_orders WHERE id='$order_id'");
    }

    echo "<script>alert('✅ All GCash orders cleared successfully.');window.location='user_orders.php';</script>";
    exit;
} else {
    echo "<script>alert('❌ No GCash orders found to clear.');window.location='user_orders.php';</script>";
    exit;
}
?>
