<?php
session_start();
include '../includes/config.php';

if (!isset($_SESSION['user'])) {
    die("❌ No session found. Please log in.");
}

$account_id = $_SESSION['user']['id'] ?? null;
if (!$account_id) die("❌ User ID not found.");

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $total = floatval($_POST['total_amount'] ?? 0);
    $product_ids = $_POST['product_ids'] ?? [];
    $quantities = $_POST['quantities'] ?? [];

    $fullname = $_POST['fullname'] ?? '';
    $address = $_POST['address'] ?? '';
    $zip_code = $_POST['zip_code'] ?? '';
    $phone = $_POST['phone'] ?? '';

    foreach ($product_ids as $index => $product_id) {
        $qty = intval($quantities[$index] ?? 0);
        $productQuery = mysqli_query($conn, "SELECT price FROM products WHERE id='$product_id'");
        $product = mysqli_fetch_assoc($productQuery);
        if (!$product) continue;

        $subtotal = $product['price'] * $qty;

        // ✅ Insert order
        mysqli_query($conn, "
            INSERT INTO user_orders (user_id, product_id, quantity, total_amount, payment_method, is_received)
            VALUES ('$account_id', '$product_id', '$qty', '$subtotal', 'GCash', 0)
        ");
        $order_id = mysqli_insert_id($conn);

        // ✅ Reduce product stock
        mysqli_query($conn, "
            UPDATE products 
            SET quantity = GREATEST(quantity - $qty, 0)
            WHERE id = '$product_id'
        ");

        // ✅ Delivery info
        mysqli_query($conn, "
            INSERT INTO order_delivery (order_id, fullname, address, zip_code, phone)
            VALUES ('$order_id', '$fullname', '$address', '$zip_code', '$phone')
        ");
    }

    // ✅ Clear cart
    mysqli_query($conn, "DELETE FROM user_cart WHERE user_id='$account_id'");

    echo "<script>alert('✅ GCash order placed successfully!');window.location='../gcash_modal/user_orders.php';</script>";
}
?>
