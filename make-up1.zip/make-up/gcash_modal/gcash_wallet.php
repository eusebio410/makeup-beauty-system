<?php
session_start();
include '../includes/config.php';

// ✅ Detect logged-in account type
if (isset($_SESSION['user'])) {
    $accountType = 'user';
    $user = $_SESSION['user'];
    $user_id = $user['id'] ?? $_SESSION['user']['user_id'] ?? null;
    $table = 'users';
} elseif (isset($_SESSION['company'])) {
    $accountType = 'company';
    $user = $_SESSION['company'];
    $user_id = $user['id'] ?? null;
    $table = 'companies';
} else {
    die("❌ No session found. Please log in.");
}

if (!$user_id) {
    die("❌ ID not found in session.");
}

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $type = $_POST['type'];
    $amount = floatval($_POST['amount']);

    if ($amount <= 0) {
        die("❌ Invalid amount");
    }

    // Deposit
    if ($type === 'deposit') {
        mysqli_query($conn, "UPDATE $table SET gcash_balance = gcash_balance + $amount WHERE id='$user_id'");

        if ($accountType === 'user') {
            mysqli_query($conn, "INSERT INTO transactions (user_id, type, amount) VALUES ('$user_id', 'deposit', '$amount')");
        } else {
            mysqli_query($conn, "INSERT INTO transactions (company_id, type, amount) VALUES ('$user_id', 'deposit', '$amount')");
        }

    // Withdraw
    } elseif ($type === 'withdraw') {
        $check = mysqli_fetch_assoc(mysqli_query($conn, "SELECT gcash_balance FROM $table WHERE id='$user_id'"));
        if ($check['gcash_balance'] < $amount) {
            die("❌ Insufficient balance to withdraw!");
        }

        mysqli_query($conn, "UPDATE $table SET gcash_balance = gcash_balance - $amount WHERE id='$user_id'");

        if ($accountType === 'user') {
            mysqli_query($conn, "INSERT INTO transactions (user_id, type, amount) VALUES ('$user_id', 'withdraw', '$amount')");
        } else {
            mysqli_query($conn, "INSERT INTO transactions (company_id, type, amount) VALUES ('$user_id', 'withdraw', '$amount')");
        }
    }

    echo "<script>alert('✅ Transaction successful!');window.location='gcash_wallet.php';</script>";
    exit;
}

// Fetch current balance
$data = mysqli_fetch_assoc(mysqli_query($conn, "SELECT gcash_balance FROM $table WHERE id='$user_id'"));
$balance = number_format($data['gcash_balance'], 2);
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>My GCash Wallet</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css" rel="stylesheet">
</head>
<body class="bg-light">

<div class="container mt-5">
  <div class="card p-4 shadow-lg position-relative">
    <h3>💰 My GCash Wallet</h3>

    <!-- Buttons to view orders -->
    <div class="mb-3 text-end">
      <div class="d-flex justify-content-end align-items-center gap-2">
        <?php if ($accountType === 'user'): ?>
          <a href="user_orders.php" class="btn btn-light">
            <i class="bi bi-bag-check"></i> My Orders
          </a>
        <?php elseif ($accountType === 'company'): ?>
          <a href="company_orders.php" class="btn btn-warning">
            <i class="bi bi-bag-check"></i> Company Orders
          </a>
        <?php endif; ?>

        <!-- Back to Home Button -->
        <a href="../user_modal/user_dashboard.php" class="btn btn-outline-secondary">
          ⬅ Back to Home
        </a>
      </div>
    </div>


    <hr>
    <h4>Current Balance: <span class="text-success">₱<?= $balance ?></span></h4>

    <form method="POST" class="mt-4">
      <div class="row g-2">
        <div class="col-md-4">
          <select name="type" class="form-select" required>
            <option value="">Select Action</option>
            <option value="deposit">Deposit</option>
            <option value="withdraw">Withdraw</option>
          </select>
        </div>
        <div class="col-md-4">
          <input type="number" min="1" name="amount" class="form-control" placeholder="Enter Amount" required>
        </div>
        <div class="col-md-4">
          <button type="submit" class="btn btn-primary w-100">Submit</button>
        </div>
      </div>
    </form>
  </div>
</div>


</body>
</html>
