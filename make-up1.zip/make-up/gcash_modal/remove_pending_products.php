<?php
include '../includes/config.php';

// Delete products marked pending_out for >2 minutes
mysqli_query($conn, "
    DELETE FROM products 
    WHERE status='pending_out' AND out_time <= NOW() - INTERVAL 2 MINUTE
");
