<?php
session_start();
if ($_POST['entered_otp'] == $_SESSION['otp']) {
  echo '
  <!-- GCash Form -->
  <form id="gcashForm" method="POST" style="display:none;">
    <input type="hidden" name="user_id" value="<?= $user_id ?>">
    <input type="hidden" name="total_amount" value="<?= $total ?>">

    <?php foreach ($cartItems as $item): ?>
      <input type="hidden" name="product_ids[]" value="<?= $item['product_id'] ?>">
      <input type="hidden" name="quantities[]" value="<?= $item['cart_qty'] ?>">
    <?php endforeach; ?>

    <div class="mb-3">
      <label>GCash Number:</label>
      <input type="text" id="gcash_number" class="form-control" required placeholder="09xxxxxxxxx">
    </div>

    <button type="button" class="btn btn-warning" id="sendCodeBtn">Send Verification Code</button>

    <div id="verifySection" style="display:none;" class="mt-3">
      <label>Enter Code:</label>
      <input type="text" id="verification_code" class="form-control" placeholder="Enter 6-digit code">
      <button type="button" id="verifyCodeBtn" class="btn btn-primary mt-3 w-100">Verify Code</button>
    </div>

    <div id="deliveryForm" style="display:none;">
      <h5>Delivery Information</h5>
      <div class="mb-3">
        <label>Full Name:</label>
        <input type="text" name="fullname" class="form-control" required>
      </div>
      <div class="mb-3">
        <label>Address:</label>
        <textarea name="address" class="form-control" required></textarea>
      </div>
      <div class="mb-3">
        <label>Zip Code:</label>
        <input type="text" name="zip_code" class="form-control" required></textarea>
      </div>
      <div class="mb-3">
        <label>Phone Number:</label>
        <input type="text" name="phone" class="form-control" required>
      </div>
      <button type="submit" formaction="process_gcash_order.php" class="btn btn-success w-100">Place GCash Order</button>
    </div>
  </form>
  ';
} else {
  echo "<script>alert('Invalid OTP'); window.location='checkout.php';</script>";
}

?>
<script>
  let generatedCode = null;

document.getElementById("sendCodeBtn").addEventListener("click", function(){
    // Generate a random 6-digit code
    generatedCode = Math.floor(100000 + Math.random() * 900000);
    alert("Verification code sent! (Simulated: " + generatedCode + ")");
    document.getElementById("verifySection").style.display = "block";
});

document.getElementById("verifyCodeBtn").addEventListener("click", function(){
    let enteredCode = document.getElementById("verification_code").value;
    if(enteredCode == generatedCode){
        alert("GCash verified!");
        document.getElementById("verifySection").style.display = "none";
        document.getElementById("deliveryForm").style.display = "block";
    } else {
        alert("❌ Invalid code. Try again.");
    }
});

</script>