<!-- Footer -->
<footer>
  © <?= date('Y'); ?> Glamour Beauty — Radiate Confidence, Shine Brighter ✨
</footer>

<!-- Scripts -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script>
// Sidebar controls
function openSidebar() {
  document.getElementById("sidebar").style.width = "250px";
  document.getElementById("sidebar").setAttribute('aria-hidden', 'false');
}
function closeSidebar() {
  document.getElementById("sidebar").style.width = "0";
  document.getElementById("sidebar").setAttribute('aria-hidden', 'true');
}

// Search filter
document.addEventListener('DOMContentLoaded', function() {
  const searchEl = document.getElementById('searchInput');
  if (searchEl) {
    searchEl.addEventListener('keyup', function(){
      let filter = this.value.toLowerCase();
      document.querySelectorAll('.product').forEach(card => {
        let title = card.querySelector('h6').textContent.toLowerCase();
        card.style.display = title.includes(filter) ? 'block' : 'none';
      });
    });
  }
});

// Category filter
function filterCategory(cat, btn) {
  document.querySelectorAll('.category-bar button').forEach(b => b.classList.remove('active'));
  btn.classList.add('active');
  const products = document.querySelectorAll('.product');
  products.forEach(p => {
    p.style.display = (cat === 'all' || p.classList.contains(cat)) ? 'block' : 'none';
  });
}
</script>
</body>
</html>
