<?php
// expects: $isLoggedIn, $role, $userData (set in parent page)
if (!isset($isLoggedIn)) $isLoggedIn = false;
if (!isset($role)) $role = null;
if (!isset($userData)) $userData = null;
?>
<!-- NAVBAR -->
<nav class="navbar navbar-expand-lg" style="padding: 10px 20px;">
  <div class="container-fluid">
    <a class="navbar-brand text-white fw-bold" href="index.php">💄 Glamour Beauty</a>

    <form class="d-flex search-bar mx-auto" role="search">
      <input class="form-control me-2" type="search" id="searchInput" placeholder="Search makeup..." aria-label="Search">
    </form>

    <ul class="navbar-nav ms-auto mb-2 mb-lg-0 align-items-center">
      <?php if(!$isLoggedIn): ?>
        <!-- Hamburger icon -->
        <li class="nav-item">
          <button class="menu-icon" onclick="openSidebar()">&#9776;</button>
        </li>
      <?php else: ?>
        <li class="nav-item me-3 text-white">
          Welcome, <strong><?= htmlspecialchars($role == 'company' ? ($userData['company_name'] ?? $userData['username']) : ($userData['username'] ?? '')); ?></strong>
        </li>
        <?php if($role == 'company'): ?>
          <li class="nav-item me-2">
            <a href="add_product.php" class="btn btn-light text-danger fw-bold px-3 py-1 rounded-pill">➕ Add Product</a>
          </li>
        <?php endif; ?>
        <li class="nav-item">
          <a href="logout.php" class="btn btn-light fw-bold px-3 py-1 rounded-pill text-danger">Logout</a>
        </li>
      <?php endif; ?>
    </ul>
  </div>
</nav>

<!-- SLIDING SIDEBAR MENU -->
<div id="sidebar" class="sidebar" aria-hidden="true">
  <span class="closebtn" onclick="closeSidebar()">&times;</span>
  <a href="login.php">Login</a>
  <a href="user_register.php">User Register</a>
  <a href="company_register.php">Company Register</a>
</div>

<!-- Category bar is part of header area for shop/index pages; leave it here so pages can show it -->
<div class="category-bar sticky-top">
  <button class="active" onclick="filterCategory('all', this)">Home</button>
  <button onclick="filterCategory('lipstick', this)">Lipstick</button>
  <button onclick="filterCategory('foundation', this)">Foundation</button>
  <button onclick="filterCategory('skincare', this)">Skincare</button>
  <button onclick="filterCategory('accessories', this)">Accessories</button>
</div>
