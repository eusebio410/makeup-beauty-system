<?php
session_start();
include '../includes/config.php';

// ✅ Allow only admin
if (!isset($_SESSION['role']) || $_SESSION['role'] != 'admin') {
    header("Location: login.php");
    exit();
}

// ✅ Handle approve/decline
if (isset($_POST['action']) && isset($_POST['product_id'])) {
    $id = $_POST['product_id'];

    if ($_POST['action'] == 'approve') {
        // ✅ Move product from pending_products to products table
        $pending = mysqli_fetch_assoc(mysqli_query($conn, "SELECT * FROM pending_products WHERE id='$id'"));
        if ($pending) {
            $insert = "INSERT INTO products (company_id, productName, brand, price, quantity, category, location, image, description, status)
                       VALUES ('{$pending['company_id']}', '{$pending['productName']}', '{$pending['brand']}', '{$pending['price']}',
                               '{$pending['quantity']}', '{$pending['category']}', '{$pending['location']}', '{$pending['image']}',
                               '{$pending['description']}', 'approved')";
            mysqli_query($conn, $insert);
            mysqli_query($conn, "DELETE FROM pending_products WHERE id='$id'");
        }
    } else {
        // ❌ Declined — just remove from pending
        mysqli_query($conn, "DELETE FROM pending_products WHERE id='$id'");
    }
}


// ✅ Fetch pending products grouped by company
$companies = mysqli_query($conn, "
    SELECT DISTINCT c.id, c.company_name
    FROM pending_products p
    JOIN companies c ON p.company_id = c.id
");

?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Admin Dashboard | Glamour Beauty</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>

<style>
body {
  background-color: #fff0f6;
  font-family: 'Poppins', sans-serif;
}
.navbar {
  background: linear-gradient(90deg, #ff3ebf, #d63384);
}
.navbar-brand {
  color: white !important;
  font-weight: bold;
}
.container {
  margin-top: 50px;
}
.company-card {
  box-shadow: 0 4px 12px rgba(255, 62, 191, 0.2);
  border-radius: 12px;
  background: #fff;
  padding: 20px;
}
.btn-view {
  background: linear-gradient(135deg, #ff3ebf, #d63384);
  color: white;
  border: none;
  padding: 8px 16px;
  border-radius: 25px;
  font-weight: 500;
  transition: 0.3s;
}
.btn-view:hover {
  transform: scale(1.05);
  background: linear-gradient(135deg, #d63384, #ff3ebf);
}
.modal-content {
  border-radius: 15px;
}
.modal-body {
  max-height: 500px;
  overflow-y: auto;
}

/* ✅ Product Card Styling */
.product-card {
  background: rgba(0, 0, 0, 0.05); /* Subtle dark shade */
  border-radius: 12px;
  box-shadow: 0 3px 10px rgba(255, 62, 191, 0.15);
  width: 170px;
  height: 280px;
  display: flex;
  flex-direction: column;
  justify-content: space-between;
  margin: 10px;
  padding: 8px;
  text-align: center;
  transition: transform 0.2s ease-in-out, box-shadow 0.2s;
}
.product-card:hover {
  transform: scale(1.03);
  box-shadow: 0 5px 15px rgba(214, 51, 132, 0.25);
}
.product-card img {
  width: 100%;
  height: 150px;
  object-fit: cover;
  border-radius: 10px;
}
.product-card h6 {
  font-size: 14px;
  margin: 6px 0 4px;
  color: #000; /* ✅ Changed to black */
  font-weight: 700; /* ✅ Bold */
}
.product-card .price {
  font-weight: bold;
  color: #d63384; /* ✅ Theme color */
  font-size: 14px;
}
.product-card small {
  color: #666;
  font-size: 12px;
}

/* ✅ Approve/Decline Buttons */
.btn-approve, .btn-decline {
  border: none;
  padding: 4px 8px;
  border-radius: 6px;
  font-size: 12px;
  color: white;
  font-weight: 500;
  transition: 0.2s;
}
.btn-approve {
  background: #28a745;
}
.btn-approve:hover {
  background: #218838;
}
.btn-decline {
  background: #dc3545;
}
.btn-decline:hover {
  background: #c82333;
}
.product-grid {
  display: flex;
  flex-wrap: wrap;
  justify-content: center;
}
.card-footer-box {
  margin-top: 6px;
  display: flex;
  justify-content: center;
  gap: 6px;
}
</style>
</head>
<body>

<!-- ✅ Navbar -->
<nav class="navbar navbar-expand-lg">
  <div class="container-fluid">
    <a class="navbar-brand" href="#">💄 Glamour Beauty Admin</a>
    <div class="d-flex ms-auto">
      <span class="text-white me-3">Welcome, Admin</span>
      <a href="../auth/logout.php" class="btn btn-light btn-sm rounded-pill text-danger fw-bold">Logout</a>
    </div>
  </div>
</nav>

<div class="container">
  <h2 class="text-center mb-4" style="color:#ff3ebf;">PENDING PRODUCT BY COMPANY</h2>

  <?php if (mysqli_num_rows($companies) > 0) { ?>
    <div class="row">
      <?php while ($company = mysqli_fetch_assoc($companies)) { ?>
        <div class="col-md-4 mb-4">
          <div class="company-card text-center">
            <h5 class="mb-3">🏢 <?= htmlspecialchars($company['company_name']) ?></h5>
            <button class="btn-view" data-bs-toggle="modal" data-bs-target="#modal<?= $company['id'] ?>">View Products</button>
          </div>
        </div>

        <!-- ✅ Modal for Each Company -->
        <div class="modal fade" id="modal<?= $company['id'] ?>" tabindex="-1" aria-hidden="true">
          <div class="modal-dialog modal-lg modal-dialog-centered">
            <div class="modal-content">
              <div class="modal-header" style="background: linear-gradient(135deg, #ff3ebf, #d63384); color:white;">
                <h5 class="modal-title">Pending Products - <?= htmlspecialchars($company['company_name']) ?></h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
              </div>
              <div class="modal-body">
                <?php
                $products = mysqli_query($conn, "SELECT * FROM pending_products WHERE company_id={$company['id']}");

                if (mysqli_num_rows($products) > 0) {
                ?>
                <div class="product-grid">
                  <?php while ($p = mysqli_fetch_assoc($products)) { ?>
                  <div class="product-card">
                    <img src="../func/<?= htmlspecialchars($p['image']) ?>" alt="<?= htmlspecialchars($p['productName']) ?>">
                    <h6><?= htmlspecialchars($p['productName']) ?></h6>
                    <div class="price">₱<?= number_format($p['price'], 2) ?></div>
                    <small>Available: <?= htmlspecialchars($p['quantity']) ?></small>
                    <small>Company: <?= htmlspecialchars($company['company_name']) ?></small>

                    <div class="card-footer-box">
                      <form method="POST" style="display:inline-block;">
                        <input type="hidden" name="product_id" value="<?= $p['id'] ?>">
                        <button name="action" value="approve" class="btn-approve">Approve</button>
                      </form>
                      <form method="POST" style="display:inline-block;">
                        <input type="hidden" name="product_id" value="<?= $p['id'] ?>">
                        <button name="action" value="decline" class="btn-decline">Decline</button>
                      </form>
                    </div>
                  </div>
                  <?php } ?>
                </div>
                <?php } else { ?>
                  <p class="text-center text-muted">No pending products for this company.</p>
                <?php } ?>
              </div>
            </div>
          </div>
        </div>
      <?php } ?>
    </div>
  <?php } else { ?>
    <div class="alert alert-info text-center">No pending products found.</div>
  <?php } ?>
</div>

</body>
</html>