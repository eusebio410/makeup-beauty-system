<form action="process_order.php" method="POST">
  <input type="hidden" name="method" value="cod">
  <div>
    <label>Delivery Address:</label>
    <textarea name="address" required></textarea>
  </div>
  <button type="submit">Place Order</button>
</form>
