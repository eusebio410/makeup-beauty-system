<?php
session_start();
include '../includes/config.php';
$user = $_SESSION['user'];
$user_id = $user['id'];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $product_ids = $_POST['product_ids'];
  $quantities = $_POST['quantities'];
  $total = $_POST['total_amount'];

  foreach ($product_ids as $index => $product_id) {
    $qty = intval($quantities[$index]);
    $product = mysqli_fetch_assoc(mysqli_query($conn, "SELECT quantity, price FROM products WHERE id='$product_id'"));

    if ($product['quantity'] < $qty) {
      echo "<script>alert('⚠️ Not enough stock!');window.history.back();</script>";
      exit;
    }

    mysqli_query($conn, "UPDATE products SET quantity = quantity - $qty WHERE id='$product_id'");
    $subtotal = $product['price'] * $qty;

    mysqli_query($conn, "
      INSERT INTO user_orders (user_id, product_id, quantity, total_amount, payment_method, status)
      VALUES ('$user_id', '$product_id', '$qty', '$subtotal', 'COD', 'Pending')
    ");
  }

  echo "<script>alert('✅ COD order placed successfully!');window.location='../user_modal/user_dashboard.php';</script>";
  // ✅ Deduct product quantity
foreach ($product_ids as $index => $product_id) {
  $qty = $quantities[$index];

  // Deduct from stock
  $updateStock = mysqli_query($conn, "
    UPDATE products 
    SET quantity = quantity - $qty 
    WHERE id = '$product_id'
  ");

  // Schedule automatic "out_of_sold" update after 2 minutes if quantity = 0
  $checkStock = mysqli_query($conn, "SELECT quantity FROM products WHERE id='$product_id'");
  $row = mysqli_fetch_assoc($checkStock);

  if ($row['quantity'] <= 0) {
    // Store timestamp of when stock reached zero
    mysqli_query($conn, "
      UPDATE products 
      SET status = 'pending_out', out_time = NOW() 
      WHERE id='$product_id'
    ");
  }
}

}
?>
