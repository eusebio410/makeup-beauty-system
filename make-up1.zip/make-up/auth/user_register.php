<?php
include '../includes/config.php';
session_start();

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $firstname = trim($_POST['firstname']);
    $lastname = trim($_POST['lastname']);
    $username = trim($_POST['username']);
    $phone = trim($_POST['phone']);
    $address = trim($_POST['address']);
    $password = trim($_POST['password']);
    $confirm_password = trim($_POST['confirm_password']);

    if (empty($firstname) || empty($lastname) || empty($username) || empty($phone) || empty($address) || empty($password) || empty($confirm_password)) {
        echo "<script>alert('⚠️ Please fill all user fields!');</script>";
    } elseif ($password !== $confirm_password) {
        echo "<script>alert('❌ Passwords do not match!');</script>";
    } else {
        $check = $conn->prepare("SELECT * FROM users WHERE username = ?");
        $check->bind_param("s", $username);
        $check->execute();
        $res = $check->get_result();

        if ($res->num_rows > 0) {
            echo "<script>alert('⚠️ Username already exists!');</script>";
        } else {
            $hashed = password_hash($password, PASSWORD_DEFAULT);
            $stmt = $conn->prepare("INSERT INTO users (firstname, lastname, username, phone, address, password) VALUES (?, ?, ?, ?, ?, ?)");
            $stmt->bind_param("ssssss", $firstname, $lastname, $username, $phone, $address, $hashed);
            
            if ($stmt->execute()) {
                echo "<script>alert('✅ User registered successfully!'); window.location='login.php';</script>";
            } else {
                echo "<script>alert('❌ Database error: {$conn->error}');</script>";
            }
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>User Registration | Glamour Beauty</title>
<style>
  .back-home-btn {
    display: inline-block;
    text-decoration: none;
    background: linear-gradient(135deg, #ff3ebf, #f8d7e3);
    color: white;
    font-weight: bold;
    padding: 12px 25px;
    border-radius: 30px;
    box-shadow: 0 4px 10px rgba(255, 62, 191, 0.4);
    transition: all 0.3s ease;
    letter-spacing: 0.5px;
  }
  .back-home-btn:hover {
    background: linear-gradient(135deg, #f8d7e3, #ff3ebf);
    transform: scale(1.05);
    box-shadow: 0 6px 15px rgba(255, 62, 191, 0.6);
  }
</style>

<style>
body {
  font-family: 'Poppins', sans-serif;
  background: #f8d7e3;
  display: flex;
  justify-content: center;
  align-items: center;
  height: 100vh;
}
.container {
  background: #fff;
  padding: 25px;
  border-radius: 10px;
  width: 380px;
  box-shadow: 0 0 10px rgba(0,0,0,0.1);
}
input, button {
  width: 100%;
  margin: 8px 0;
  padding: 10px;
  border: 1px solid #ccc;
  border-radius: 5px;
}
button {
  background: #ff3ebf;
  color: white;
  font-weight: bold;
}
button:hover {
  background: #c72a8c;
}
</style>
</head>
<body>
<div class="container">
  <h2>💄 User Registration</h2>
  <form method="POST">
    <input type="text" name="firstname" placeholder="First Name">
    <input type="text" name="lastname" placeholder="Last Name">
    <input type="text" name="username" placeholder="Username">
    <input type="text" name="phone" placeholder="Phone Number">
    <input type="text" name="address" placeholder="Address">
    <input type="password" name="password" placeholder="Password">
    <input type="password" name="confirm_password" placeholder="Confirm Password">
    <button type="submit">Register</button>
    <p>Already have an account? <a href="login.php">Login</a></p>
    <a href="../index.php" class="back-home-btn">← Back to Home</a>

  </form>
</div>
</body>
</html>
