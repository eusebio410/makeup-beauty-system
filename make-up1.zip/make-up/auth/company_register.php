<?php
include '../includes/config.php';
session_start();

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $company_name = trim($_POST['company_name']);
    $phone = trim($_POST['phone']);
    $address = trim($_POST['address']);
    $password = trim($_POST['password']);
    $license_photo = $_FILES['license_photo']['name'];
    $target_dir = "uploads/";
    $target_file = $target_dir . basename($license_photo);

    if (empty($company_name) || empty($phone) || empty($address) || empty($password) || empty($license_photo)) {
        echo "<script>alert('⚠️ Please fill all company fields!');</script>";
    } else {
        $hashed = password_hash($password, PASSWORD_DEFAULT);
        if (!file_exists('uploads')) mkdir('uploads');
        move_uploaded_file($_FILES["license_photo"]["tmp_name"], $target_file);

        $stmt = $conn->prepare("INSERT INTO companies (company_name, phone, address, license_photo, password) VALUES (?, ?, ?, ?, ?)");
        $stmt->bind_param("sssss", $company_name, $phone, $address, $target_file, $hashed);

        if ($stmt->execute()) {
            echo "<script>alert('✅ Company registered successfully!'); window.location='login.php';</script>";
        } else {
            echo "<script>alert('❌ Database error: {$conn->error}');</script>";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Company Registration | Glamour Beauty</title>
<style>
  .back-home-btn {
    display: inline-block;
    text-decoration: none;
    background: linear-gradient(135deg, #ff3ebf, #f8d7e3);
    color: white;
    font-weight: bold;
    padding: 12px 25px;
    border-radius: 30px;
    box-shadow: 0 4px 10px rgba(255, 62, 191, 0.4);
    transition: all 0.3s ease;
    letter-spacing: 0.5px;
  }
  .back-home-btn:hover {
    background: linear-gradient(135deg, #f8d7e3, #ff3ebf);
    transform: scale(1.05);
    box-shadow: 0 6px 15px rgba(255, 62, 191, 0.6);
  }
</style>
<style>
body {
  font-family: 'Poppins', sans-serif;
  background: #f8d7e3;
  display: flex;
  justify-content: center;
  align-items: center;
  height: 100vh;
}
.container {
  background: #fff;
  padding: 25px;
  border-radius: 10px;
  width: 380px;
  box-shadow: 0 0 10px rgba(0,0,0,0.1);
}
input, button {
  width: 100%;
  margin: 8px 0;
  padding: 10px;
  border: 1px solid #ccc;
  border-radius: 5px;
}
button {
  background: #ff3ebf;
  color: white;
  font-weight: bold;
}
button:hover {
  background: #c72a8c;
}
</style>
</head>
<body>
<div class="container">
  <h2>🏬 Company Registration</h2>
  <form method="POST" enctype="multipart/form-data">
    <input type="text" name="company_name" placeholder="Company Name">
    <input type="text" name="phone" placeholder="Phone Number">
    <input type="text" name="address" placeholder="Address">
    <input type="password" name="password" placeholder="Password">
    <label>Upload License Photo (Required)</label>
    <input type="file" name="license_photo" accept="image/*">
    <small style="color:#ff3ebf;">📢 Please upload a valid business license for verification.</small>
    <button type="submit">Register</button>
    <p>Already have an account? <a href="login.php">Login</a></p>
    <a href="../index.php" class="back-home-btn">← Back to Home</a>
  </form>
</div>
</body>
</html>
