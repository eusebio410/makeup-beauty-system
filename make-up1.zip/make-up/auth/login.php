<?php
include '../includes/config.php';
session_start();

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = trim($_POST['username']);
    $password = trim($_POST['password']);
    $role = $_POST['role'];

    if ($role == 'admin') {
        // 🔹 Admin Login
        $stmt = $conn->prepare("SELECT * FROM admin WHERE username = ?");
        $stmt->bind_param("s", $username);
        $stmt->execute();
        $res = $stmt->get_result();

        if ($res->num_rows > 0) {
            $admin = $res->fetch_assoc();
            if (md5($password) === $admin['password']) {
                $_SESSION['admin'] = $admin;
                $_SESSION['role'] = 'admin';
                echo "<script>alert('👑 Welcome back, Admin!'); window.location='../admin/admin_dashboard.php';</script>";
                exit;
            } else {
                echo "<script>alert('❌ Invalid admin password!');</script>";
            }
        } else {
            echo "<script>alert('⚠️ Admin not found!');</script>";
        }
    }

    // 🔹 User Login
    if ($role == 'user') {
        $stmt = $conn->prepare("SELECT * FROM users WHERE username = ?");
        $stmt->bind_param("s", $username);
        $stmt->execute();
        $res = $stmt->get_result();

        if ($res->num_rows > 0) {
            $data = $res->fetch_assoc();
            if (password_verify($password, $data['password'])) {
                $_SESSION['user'] = $data;
                $_SESSION['role'] = 'user';
                echo "<script>alert('✅ Welcome back, {$data['username']}!'); window.location='../user_modal/user_dashboard.php';</script>";
                exit;
            } else {
                echo "<script>alert('❌ Invalid password!');</script>";
            }
        } else {
            echo "<script>alert('⚠️ User not found!');</script>";
        }
    }

    // 🔹 Company Login
    if ($role == 'company') {
        $stmt = $conn->prepare("SELECT * FROM companies WHERE company_name = ?");
        $stmt->bind_param("s", $username);
        $stmt->execute();
        $res = $stmt->get_result();

        if ($res->num_rows > 0) {
            $data = $res->fetch_assoc();
            if (password_verify($password, $data['password'])) {
                $_SESSION['company'] = $data;
                $_SESSION['role'] = 'company';
                echo "<script>alert('🏢 Welcome back, {$data['company_name']}!'); window.location='../company_modal/company_dashboard.php';</script>";
                exit;
            } else {
                echo "<script>alert('❌ Invalid password!');</script>";
            }
        } else {
            echo "<script>alert('⚠️ Company not found!');</script>";
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Login | Glamour Beauty</title>
<style>
body {
  font-family: 'Poppins', sans-serif;
  background-color: #f8d7e3;
  display: flex;
  justify-content: center;
  align-items: center;
  height: 100vh;
}
.container {
  background: #fff;
  padding: 25px;
  border-radius: 15px;
  width: 380px;
  box-shadow: 0 4px 15px rgba(0,0,0,0.1);
  text-align: center;
}
h2 {
  color: #d63384;
  margin-bottom: 20px;
}
input, select, button {
  width: 100%;
  margin: 8px 0;
  padding: 10px;
  border: 1px solid #ccc;
  border-radius: 8px;
  font-size: 14px;
}
button {
  background: linear-gradient(135deg, #ff3ebf, #d63384);
  color: white;
  font-weight: bold;
  cursor: pointer;
  border: none;
  transition: 0.3s;
  border-radius: 30px;
}
button:hover {
  background: linear-gradient(135deg, #f8d7e3, #ff3ebf);
  transform: scale(1.03);
}
.back-home-btn {
  display: inline-block;
  text-decoration: none;
  background: linear-gradient(135deg, #ff3ebf, #f8d7e3);
  color: white;
  font-weight: bold;
  padding: 10px 22px;
  border-radius: 30px;
  box-shadow: 0 4px 10px rgba(255, 62, 191, 0.4);
  transition: all 0.3s ease;
  margin-top: 12px;
}
.back-home-btn:hover {
  background: linear-gradient(135deg, #f8d7e3, #ff3ebf);
  transform: scale(1.05);
  box-shadow: 0 6px 15px rgba(255, 62, 191, 0.6);
}
</style>
</head>
<body>
<div class="container">
  <h2>💄 Glamour Beauty Login</h2>
  <form method="POST">
    <select name="role" required>
      <option value="">-- Select Role --</option>
      <option value="user">User</option>
      <option value="company">Company</option>
      <option value="admin">Admin</option>
    </select>
    <input type="text" name="username" placeholder="Username / Company Name / Admin Username" required>
    <input type="password" name="password" placeholder="Password" required>
    <button type="submit">Login</button>
    <p>Don’t have an account? 
      <a href="user_register.php">User Register</a> | 
      <a href="company_register.php">Company Register</a>
    </p>
    <a href="../index.php" class="back-home-btn">← Back to Home</a>
  </form>
</div>
</body>
</html>
