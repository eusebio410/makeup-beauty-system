<?php
session_start();
include '../includes/config.php';

if (!isset($_SESSION['user'])) {
  header("Location: login.php");
  exit();
}

$user_id = $_SESSION['user']['id'];

$result = mysqli_query($conn, "
  SELECT c.*, p.productName, p.price, p.image 
  FROM cart c
  JOIN products p ON c.product_id = p.id
  WHERE c.user_id = '$user_id'
");

?>
<!DOCTYPE html>
<html>
<head>
  <title>Your Cart | Glamour Beauty</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<div class="container mt-5">
  <h2 class="mb-4 text-center">🛒 Your Shopping Cart</h2>
  <?php if(mysqli_num_rows($result) > 0): ?>
    <table class="table table-bordered text-center align-middle">
      <thead class="table-dark">
        <tr>
          <th>Product</th>
          <th>Name</th>
          <th>Price</th>
          <th>Quantity</th>
          <th>Total</th>
        </tr>
      </thead>
      <tbody>
        <?php
        $grandTotal = 0;
        while ($row = mysqli_fetch_assoc($result)) {
          $total = $row['price'] * $row['quantity'];
          $grandTotal += $total;
          echo "
          <tr>
            <td><img src='{$row['image']}' width='80'></td>
            <td>{$row['productName']}</td>
            <td>₱" . number_format($row['price']) . "</td>
            <td>{$row['quantity']}</td>
            <td>₱" . number_format($total) . "</td>
          </tr>";
        }
        ?>
      </tbody>
    </table>
    <h4 class="text-end me-5">Total: ₱<?= number_format($grandTotal) ?></h4>
  <?php else: ?>
    <p class="text-center">Your cart is empty 😔</p>
  <?php endif; ?>
</div>
</body>
</html>
