<?php
session_start();
include '../includes/config.php';

// ✅ Ensure only logged-in user can access this page
if (!isset($_SESSION['user'])) {
    header("Location: ../login.php");
    exit();
}

$user = $_SESSION['user'];
$user_id = $user['id'] ?? $_SESSION['user']['user_id'] ?? null;

if (!$user_id) {
    die("❌ User ID not found in session.");
}

$cartTable = 'user_cart';
$idColumn = 'user_id';

// 🧠 Detect if this is a “Buy Now” request
$product_id = $_POST['product_id'] ?? null;
$quantity = $_POST['quantity'] ?? null;

$cartItems = [];
$total = 0;

if ($product_id && $quantity) {
    // ✅ Buy Now Flow
    $query = mysqli_query($conn, "SELECT * FROM products WHERE id='$product_id' AND status='approved'");
    if (!$query) die("❌ Database error: " . mysqli_error($conn));
    if (mysqli_num_rows($query) === 0) die("❌ Product not found or not approved.");

    $product = mysqli_fetch_assoc($query);
    $subtotal = $product['price'] * $quantity;
    $total = $subtotal;

    $cartItems[] = [
        'product_id' => $product['id'],
        'productName' => $product['productName'],
        'price' => $product['price'],
        'image' => $product['image'],
        'cart_qty' => $quantity
    ];
} else {
    // ✅ Cart Checkout Flow
    $cartQuery = mysqli_query($conn, "
        SELECT c.id AS cart_id, c.quantity AS cart_qty, 
               p.id AS product_id, p.productName, p.price, p.image 
        FROM $cartTable c
        JOIN products p ON c.product_id = p.id
        WHERE c.$idColumn='$user_id'
    ");
    if (!$cartQuery) die("❌ Database error: " . mysqli_error($conn));
    if (mysqli_num_rows($cartQuery) === 0) die("❌ Your cart is empty. Add products before checkout.");

    while ($row = mysqli_fetch_assoc($cartQuery)) {
        $cartItems[] = $row;
        $total += $row['price'] * $row['cart_qty'];
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Checkout | Glamour Beauty</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css" rel="stylesheet">
<style>
  body {
    background: linear-gradient(to bottom right, #ffe6f2, #f7f7ff);
    font-family: 'Poppins', sans-serif;
  }

  .cart-card {
    border-radius: 12px;
    background: #fff;
    box-shadow: 0 2px 8px rgba(0,0,0,0.1);
    padding: 15px;
    transition: transform 0.3s ease;
  }

  .cart-card:hover { transform: translateY(-5px); }

  .cart-img {
    width: 100%;
    height: 180px;
    object-fit: cover;
    border-radius: 10px;
    cursor: pointer;
  }

  .product-title {
    font-weight: 600;
    margin-top: 10px;
  }

  .price-tag {
    color: #e60073;
    font-weight: bold;
  }

  .discount-badge {
    background-color: #ffd6e7;
    color: #e60073;
    padding: 3px 7px;
    font-size: 12px;
    border-radius: 8px;
    margin-left: 5px;
  }

  .checkout-card {
    border-radius: 16px;
    background: #fff;
    box-shadow: 0 5px 20px rgba(0,0,0,0.08);
    overflow: hidden;
    margin-top: 40px;
  }

  .checkout-header {
    background: #ff7eb3;
    color: white;
    padding: 15px 25px;
    border-bottom: 3px solid #ff4da6;
  }

  .summary-box {
    background: #fff8fb;
    border-radius: 10px;
    padding: 15px;
    margin-top: 15px;
  }

  .payment-section {
    background: #ffffff;
    padding: 25px;
    border-top: 2px solid #ffe6f2;
    border-radius: 0 0 16px 16px;
  }

  .btn-modern {
    border: none;
    border-radius: 10px;
    font-weight: 600;
    transition: all 0.3s ease;
  }

  .btn-modern:hover { transform: scale(1.05); }

  .btn-primary { background-color: #ff7eb3; }
  .btn-success { background-color: #6bcf8b; }

  /* ✅ Modal for image view */
  #imageModal {
    display: none;
    position: fixed;
    z-index: 1050;
    padding-top: 60px;
    left: 0;
    top: 0;
    width: 100%;
    height: 100%;
    overflow: auto;
    background-color: rgba(0,0,0,0.8);
  }

  #imageModal img {
    display: block;
    margin: auto;
    max-width: 90%;
    max-height: 80%;
    border: 4px solid #fff;
    border-radius: 10px;
    animation: zoomIn 0.3s ease;
  }

  #imageModal .close {
    position: absolute;
    top: 20px;
    right: 35px;
    color: #fff;
    font-size: 40px;
    font-weight: bold;
    cursor: pointer;
  }

  @keyframes zoomIn {
    from {transform: scale(0.8); opacity: 0;}
    to {transform: scale(1); opacity: 1;}
  }
</style>
</head>
<body>

<div class="container checkout-card">
  <div class="checkout-header d-flex justify-content-between align-items-center">
    <h4 class="mb-0"><i class="bi bi-cart-check"></i> Checkout</h4>
    <div>
     <a href="../gcash_modal/user_orders.php" class="btn btn-light btn-sm">
      <i class="bi bi-bag-check"></i> My Orders
     </a>
     <a href="../user_modal/user_dashboard.php" class="btn btn-light secondary">
      ⬅ Back to Home
     </a>
  </div>
  </div>

  <div class="p-4">
    <h5 class="mb-3 text-secondary"><?= count($cartItems) > 1 ? "Your Cart Items" : "Item for Checkout" ?></h5>

    <div class="row g-4">
      <?php foreach ($cartItems as $item): ?>
      <div class="col-md-3 col-sm-4">
        <div class="cart-card text-center p-3">
          <img src="../func/<?= htmlspecialchars($item['image']) ?>" 
               alt="Product Image" 
               class="cart-img"
               onclick="openImageModal('../func/<?= htmlspecialchars($item['image']) ?>')">

          <h6 class="product-title mt-2"><?= htmlspecialchars($item['productName']) ?></h6>
          <p class="price-tag">₱<?= number_format($item['price'], 2) ?> 
          </p>

          <form method="POST" action="" class="mb-2">
            <input type="hidden" name="cart_id" value="<?= $item['cart_id'] ?? '' ?>">
            <p class="form-control mb-2 bg-light text-center">
              Quantity: <strong><?= htmlspecialchars($item['cart_qty']) ?></strong>
            </p>
          </form>


          <p><strong>Subtotal:</strong> ₱<?= number_format($item['price'] * $item['cart_qty'], 2) ?></p>
        </div>
      </div>
      <?php endforeach; ?>
    </div>

    <div class="summary-box d-flex justify-content-between align-items-center mt-4">
      <h5 class="mb-0">Total:</h5>
      <h5 class="text-success mb-0">₱<?= number_format($total, 2) ?></h5>
    </div>
  </div>

  <!-- ✅ Payment Section -->
  <div class="payment-section">
    <h5 class="text-center mb-3">💳 Choose Your Payment Method</h5>
    <div class="text-center mb-4">
      <button class="btn btn-primary btn-modern me-2" onclick="showGcash()">Pay with GCash</button>
      <button class="btn btn-success btn-modern" onclick="showCOD()">Cash on Delivery</button>
    </div>

    <!-- ✅ GCash Form -->
    <form id="gcashForm" action="../gcash_modal/process_gcash.php" method="POST" style="display:none;">
      <input type="hidden" name="user_id" value="<?= $user_id ?>">
      <input type="hidden" name="total_amount" value="<?= $total ?>">
      <?php foreach ($cartItems as $item): ?>
        <input type="hidden" name="product_ids[]" value="<?= $item['product_id'] ?>">
        <input type="hidden" name="quantities[]" value="<?= $item['cart_qty'] ?>">
      <?php endforeach; ?>
      <div id="gcashStep1">
        <label>GCash Number:</label>
        <input type="text" name="gcash_number" class="form-control mb-2" placeholder="09xxxxxxxxx" required>
        <button type="button" class="btn btn-warning w-100 btn-modern" onclick="sendVerificationCode()">Send Verification Code</button>
      </div>
      <div id="gcashStep2" style="display:none;" class="mt-3">
        <label>Enter Verification Code:</label>
        <input type="text" id="gcash_code_input" class="form-control" placeholder="Enter 6-digit code">
        <button type="button" class="btn btn-primary w-100 mt-2 btn-modern" onclick="verifyCode()">Verify Code</button>
      </div>
      <div id="gcashStep3" style="display:none;" class="mt-3">
        <div class="mb-3"><label>Full Name:</label><input type="text" name="fullname" class="form-control" required></div>
        <div class="mb-3"><label>Address:</label><textarea name="address" class="form-control" required></textarea></div>
        <div class="mb-3"><label>Zip Code:</label><input type="text" name="zip_code" class="form-control" required></div>
        <div class="mb-3"><label>Phone Number:</label><input type="text" name="phone" class="form-control" required></div>
        <button type="submit" class="btn btn-success w-100 btn-modern">Place GCash Order</button>
      </div>
    </form>

    <!-- ✅ COD Form -->
    <form id="codForm" action="../cod_modal/process_cod.php" method="POST" style="display:none;">
      <input type="hidden" name="user_id" value="<?= $user_id ?>">
      <input type="hidden" name="total_amount" value="<?= $total ?>">
      <?php foreach ($cartItems as $item): ?>
        <input type="hidden" name="product_ids[]" value="<?= $item['product_id'] ?>">
        <input type="hidden" name="quantities[]" value="<?= $item['cart_qty'] ?>">
      <?php endforeach; ?>
      <div class="mb-3"><label>Full Name:</label><input type="text" name="fullname" class="form-control" required></div>
      <div class="mb-3"><label>Address:</label><textarea name="address" class="form-control" required></textarea></div>
      <div class="mb-3"><label>Zip Code:</label><input type="text" name="zip_code" class="form-control" required></div>
      <div class="mb-3"><label>Phone Number:</label><input type="text" name="phone" class="form-control" required></div>
      <button type="submit" class="btn btn-success w-100 btn-modern">Place COD Order</button>
    </form>
  </div>
</div>

<!-- ✅ Image Modal -->
<div id="imageModal">
  <span class="close" onclick="closeImageModal()">&times;</span>
  <img id="modalImg" src="../func/">
</div>

<script>
let generatedCode = "";

function openImageModal(src) {
  document.getElementById("modalImg").src = src;
  document.getElementById("imageModal").style.display = "block";
}

function closeImageModal() {
  document.getElementById("imageModal").style.display = "none";
}

window.onclick = function(event) {
  const modal = document.getElementById('imageModal');
  if (event.target === modal) modal.style.display = "none";
}

function showGcash(){
  document.getElementById("gcashForm").style.display = "block";
  document.getElementById("codForm").style.display = "none";
  document.getElementById("gcashStep1").style.display = "block";
  document.getElementById("gcashStep2").style.display = "none";
  document.getElementById("gcashStep3").style.display = "none";
  window.scrollTo({ top: document.body.scrollHeight, behavior: 'smooth' });
}

function showCOD(){
  document.getElementById("gcashForm").style.display = "none";
  document.getElementById("codForm").style.display = "block";
  window.scrollTo({ top: document.body.scrollHeight, behavior: 'smooth' });
}

function sendVerificationCode() {
  generatedCode = Math.floor(100000 + Math.random() * 900000);
  alert("✅ Verification code sent! (Simulated code: " + generatedCode + ")");
  document.getElementById("gcashStep1").style.display = "none";
  document.getElementById("gcashStep2").style.display = "block";
}

function verifyCode() {
  let userCode = document.getElementById("gcash_code_input").value;
  if(userCode == generatedCode){
    alert("✅ Code verified successfully!");
    document.getElementById("gcashStep2").style.display = "none";
    document.getElementById("gcashStep3").style.display = "block";
  } else {
    alert("❌ Incorrect code. Try again.");
  }
}
</script>
</body>
</html>
