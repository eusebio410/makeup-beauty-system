<?php
include '../config.php';
$conn->query("DELETE FROM products WHERE quantity <= 0 AND TIMESTAMPDIFF(MINUTE, created_at, NOW()) >= 1");
?>
