<?php
session_start();
include '../includes/config.php';

if (!isset($_SESSION['company'])) {
    header("Location: ../auth/company_login.php");
    exit();
}

$company_id = $_SESSION['company']['id'];

// Fetch products and group them by category
$products_query = mysqli_query($conn, "
    SELECT * FROM products 
    WHERE company_id='$company_id' 
    ORDER BY category ASC, created_at DESC
");

$products_by_category = [];

while ($row = mysqli_fetch_assoc($products_query)) {
    $category = $row['category'];
    $products_by_category[$category][] = $row;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Product History | Glamour Beauty</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap" rel="stylesheet">
  <style>
    body {
      font-family: 'Poppins', sans-serif;
      background-color: #fff0f6;
    }
    .container {
      max-width: 900px;
      margin: 50px auto;
      background: white;
      padding: 25px;
      border-radius: 12px;
      box-shadow: 0 4px 10px rgba(255,62,191,0.2);
    }
    h3 {
      color: #ff3ebf;
      font-weight: 700;
    }
    h5 {
      color: #d63384;
      font-weight: 600;
      margin-top: 30px;
      margin-bottom: 15px;
    }
    .card {
      border: 1px solid #ffcce6;
      border-radius: 10px;
      font-size: 14px;
      padding: 10px;
    }
    .card-img-top {
      height: 160px;
      object-fit: cover;
      border-top-left-radius: 10px;
      border-top-right-radius: 10px;
      cursor: pointer;
    }
    .card-title {
      font-size: 15px;
      font-weight: 600;
      margin-bottom: 5px;
    }
    .card-text {
      font-size: 13px;
      margin-bottom: 4px;
    }
    .badge {
      font-size: 12px;
    }
    .col-md-3 {
      padding-left: 8px;
      padding-right: 8px;
    }
  </style>
</head>
<body>

<div class="container">
  <div class="d-flex justify-content-between align-items-center mb-3">
    <h3>📦 Product History</h3>
    <a href="../company_modal/company_dashboard.php" class="btn btn-light">⬅ Back to Dashboard</a>
  </div>

  <?php if (!empty($products_by_category)): ?>
    <?php foreach ($products_by_category as $category => $products): ?>
      <div class="category-section">
        <h5>📁 Category: <?= htmlspecialchars($category); ?></h5>
        <div class="row">
          <?php foreach ($products as $product): ?>
            <div class="col-md-3 mb-3">
              <div class="card h-100 shadow-sm">
                <img 
                  src="../func/<?= $product['image']; ?>" 
                  class="card-img-top product-image" 
                  alt="Product Image"
                  data-bs-toggle="modal" 
                  data-bs-target="#imageModal"
                  data-img="../func/<?= $product['image']; ?>"
                >
                <div class="card-body">
                  <h5 class="card-title"><?= htmlspecialchars($product['productName']); ?></h5>
                  <p class="card-text text-danger fw-semibold">₱<?= number_format($product['price']); ?></p>
                  <p class="card-text mb-1">Available: <strong><?= $product['quantity']; ?></strong></p>
                  <p class="card-text">Status: 
                    <?php if ($product['status'] == 'approved'): ?>
                      <span class="badge bg-success">Approved</span>
                    <?php elseif ($product['status'] == 'pending'): ?>
                      <span class="badge bg-warning text-dark">Pending</span>
                    <?php else: ?>
                      <span class="badge bg-danger"><?= ucfirst($product['status']); ?></span>
                    <?php endif; ?>
                  </p>
                  <p class="card-text">
                    <small class="text-muted">Date Added: <?= date('M d, Y', strtotime($product['created_at'])); ?></small>
                  </p>
                </div>
              </div>
            </div>
          <?php endforeach; ?>
        </div>
      </div>
    <?php endforeach; ?>
  <?php else: ?>
    <p class="text-center text-muted">No product history available.</p>
  <?php endif; ?>
</div>

<!-- 🔍 Modal for Viewing Full-Size Images -->
<div class="modal fade" id="imageModal" tabindex="-1" aria-labelledby="imageModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered modal-lg">
    <div class="modal-content bg-white">
      <div class="modal-header">
        <h5 class="modal-title" id="imageModalLabel">📸 Product Image</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body text-center">
        <img id="modalImage" src="" class="img-fluid rounded" alt="Full Size">
      </div>
    </div>
  </div>
</div>

<!-- ✅ JavaScript to Show Image in Modal -->
<script>
  const modalImage = document.getElementById('modalImage');

  document.querySelectorAll('.product-image').forEach(img => {
    img.addEventListener('click', () => {
      const src = img.getAttribute('data-img');
      modalImage.src = src;
    });
  });
</script>

<!-- ✅ Bootstrap Bundle JS (required for modal) -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>

</body>
</html>
