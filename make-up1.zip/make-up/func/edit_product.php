<?php
session_start();
include '../includes/config.php';

// ✅ Ensure company is logged in
if (!isset($_SESSION['company'])) {
    header("Location: ../auth/company_login.php");
    exit();
}

$company_id = $_SESSION['company']['id'];
$product_id = $_GET['id'] ?? 0;

// ✅ Fetch product
$product = mysqli_fetch_assoc(mysqli_query($conn, "SELECT * FROM products WHERE id='$product_id' AND company_id='$company_id'"));
if (!$product) {
    die("❌ Product not found or unauthorized access.");
}

// ✅ Handle update
if (isset($_POST['update'])) {
    $name = mysqli_real_escape_string($conn, $_POST['name']);
    $category = mysqli_real_escape_string($conn, $_POST['category']);
    $price = (float) $_POST['price'];
    $quantity = (int) $_POST['quantity'];
    $status = mysqli_real_escape_string($conn, $_POST['status']);

    // Optional image update
    $image = $product['image'];
    if (!empty($_FILES['image']['name'])) {
        $targetDir = "../uploads/";
        $fileName = time() . "_" . basename($_FILES["image"]["name"]);
        $targetFilePath = $targetDir . $fileName;
        move_uploaded_file($_FILES["image"]["tmp_name"], $targetFilePath);
        $image = "uploads/" . $fileName;
    }

    // ✅ Update query
    $update = mysqli_query($conn, "
        UPDATE products 
        SET productName='$name', category='$category', price='$price', quantity='$quantity', image='$image', status='$status'
        WHERE id='$product_id' AND company_id='$company_id'
    ");

    if ($update) {
        echo "<script>
            alert('✅ Product updated successfully!');
            window.location.href='../company_modal/company_dashboard.php';
        </script>";
        exit();
    } else {
        echo "<script>alert('❌ Update failed. Please try again.');</script>";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Edit Product | Glamour Beauty</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap" rel="stylesheet">
<style>
body { font-family: 'Poppins', sans-serif; background-color: #fff0f6; }
.container { background: white; border-radius: 12px; padding: 30px; margin-top: 50px; box-shadow: 0 4px 10px rgba(255,62,191,0.2); }
h3 { color: #ff3ebf; font-weight: 700; }
.btn-pink { background: linear-gradient(135deg, #ff3ebf, #ff69b4); color: white; border: none; }
</style>
</head>
<body>

<div class="container">
  <h3 class="text-center mb-4">✏️ Edit Product</h3>
  <form method="POST" enctype="multipart/form-data">
    <div class="mb-3">
      <label class="form-label">Product Name</label>
      <input type="text" name="name" value="<?= htmlspecialchars($product['productName']); ?>" class="form-control" required>
    </div>
    <div class="mb-3">
      <label class="form-label">Category</label>
      <input type="text" name="category" value="<?= htmlspecialchars($product['category']); ?>" class="form-control" required>
    </div>
    <div class="mb-3">
      <label class="form-label">Price (₱)</label>
      <input type="number" step="0.01" name="price" value="<?= $product['price']; ?>" class="form-control" required>
    </div>
    <div class="mb-3">
      <label class="form-label">Quantity</label>
      <input type="number" name="quantity" value="<?= $product['quantity']; ?>" class="form-control" required>
    </div>
    <div class="mb-3">
      <label class="form-label">Product Image</label><br>
      <img src="../<?= $product['image']; ?>" width="80" class="rounded mb-2"><br>
      <input type="file" name="image" class="form-control">
    </div>
    <div class="mb-3">
      <label class="form-label">Status</label>
      <select name="status" class="form-select">
        <option value="approved" <?= $product['status']=='approved'?'selected':''; ?>>Approved</option>
        <option value="pending" <?= $product['status']=='pending'?'selected':''; ?>>Pending</option>
        <option value="out_of_sold" <?= $product['status']=='out_of_sold'?'selected':''; ?>>Out of Sold</option>
      </select>
    </div>
    <div class="text-center">
      <button type="submit" name="update" class="btn btn-pink px-4">Update Product</button>
      <a href="../company_modal/company_dashboard.php" class="btn btn-secondary ms-2">Cancel</a>
    </div>
  </form>
</div>
</body>
</html>
