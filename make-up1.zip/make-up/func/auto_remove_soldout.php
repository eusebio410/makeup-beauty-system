<?php
include '../includes/config.php';

// ✅ Select products that are out of stock for 2+ minutes
$query = mysqli_query($conn, "
  SELECT id, productName, quantity, updated_at 
  FROM products 
  WHERE quantity <= 0 AND status != 'out_of_sold'
");

while ($row = mysqli_fetch_assoc($query)) {
  $productId = $row['id'];

  // Calculate how long since last update (when quantity hit zero)
  $updatedAt = strtotime($row['updated_at']);
  $now = time();
  $minutesPassed = ($now - $updatedAt) / 60;

  if ($minutesPassed >= 2) {
    // ✅ Update status to out_of_sold
    mysqli_query($conn, "
      UPDATE products 
      SET status = 'out_of_sold' 
      WHERE id = '$productId'
    ");

    // Optional: delete product entirely after 2 minutes
    // mysqli_query($conn, "DELETE FROM products WHERE id='$productId'");

    echo "Product '{$row['productName']}' marked as OUT OF SOLD.<br>";
  }
}

echo "✅ Auto-check complete.";
?>
