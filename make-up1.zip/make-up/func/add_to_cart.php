<?php
session_start();
include '../includes/config.php'; // Ensure $conn is defined

// Show errors during development (remove or disable in production)
ini_set('display_errors', 1);
error_reporting(E_ALL);

// ✅ Ensure user is logged in
if (!isset($_SESSION['user'])) {
    die("❌ No user session found. Please log in.");
}

// ✅ Define user variables
$id = $_SESSION['user']['id'] ?? $_SESSION['user']['user_id'] ?? null;
$table = 'user_cart';
$column = 'user_id';
$redirect = '../user/user_cart.php';

// ✅ Validate ID
if (!$id) {
    die("❌ Invalid user ID.");
}

// ✅ Only proceed on POST with product_id
if ($_SERVER['REQUEST_METHOD'] === 'POST' && !empty($_POST['product_id'])) {
    $product_id = (int)$_POST['product_id'];

    // ✅ Get product details (only approved)
    $stmt = $conn->prepare("SELECT productName, price, image, quantity FROM products WHERE id = ? AND status = 'approved' LIMIT 1");
    if (!$stmt) {
        die("Prepare failed: " . $conn->error);
    }
    $stmt->bind_param('i', $product_id);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows === 0) {
        echo "<script>alert('⚠️ Product not found or not approved.'); window.history.back();</script>";
        exit;
    }

    $product = $result->fetch_assoc();
    $product_name = $product['productName'];
    $price = $product['price'];
    $image = $product['image'];
    $availableStock = (int)$product['quantity'];
    $stmt->close();

    // ✅ Check if product already exists in cart
    $check_sql = "SELECT id, quantity FROM $table WHERE $column = ? AND product_id = ? LIMIT 1";
    $stmt = $conn->prepare($check_sql);
    if (!$stmt) {
        die("Prepare failed: " . $conn->error);
    }
    $stmt->bind_param('ii', $id, $product_id);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        // Product already in cart → increase quantity by 1
        $cartItem = $result->fetch_assoc();
        $newQty = $cartItem['quantity'] + 1;

        if ($newQty > $availableStock) {
            echo "<script>alert('⚠️ Not enough stock available!'); window.history.back();</script>";
            exit;
        }

        $update_sql = "UPDATE $table SET quantity = ? WHERE id = ?";
        $update_stmt = $conn->prepare($update_sql);
        if (!$update_stmt) {
            die("Prepare failed: " . $conn->error);
        }
        $update_stmt->bind_param('ii', $newQty, $cartItem['id']);
        $update_stmt->execute();

        if ($update_stmt->affected_rows <= 0) {
            echo "<script>alert('⚠️ Failed to update cart quantity. Please try again.'); window.history.back();</script>";
            exit;
        }
        $update_stmt->close();

    } else {
        // Product not in cart → add new entry
        if ($availableStock <= 0) {
            echo "<script>alert('⚠️ Product is out of stock!'); window.history.back();</script>";
            exit;
        }

        $insert_sql = "INSERT INTO $table ($column, product_id, product_name, price, image, quantity)
                       VALUES (?, ?, ?, ?, ?, 1)";
        $insert_stmt = $conn->prepare($insert_sql);
        if (!$insert_stmt) {
            die("Prepare failed: " . $conn->error);
        }
        $insert_stmt->bind_param('iisds', $id, $product_id, $product_name, $price, $image);
        $insert_stmt->execute();

        if ($insert_stmt->affected_rows <= 0) {
            echo "<script>alert('⚠️ Failed to add product to cart. Please try again.'); window.history.back();</script>";
            exit;
        }
        $insert_stmt->close();
    }

    $stmt->close();

    // ✅ Redirect after success
    echo "<script>alert('✅ Product added to cart successfully!'); window.location.href='$redirect';</script>";
    exit;

} else {
    die("❌ Invalid request.");
}
?>
