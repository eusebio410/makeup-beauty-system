<?php
session_start();
include '../includes/config.php';

// ✅ Ensure only logged-in company can access this page
if (!isset($_SESSION['company']) || $_SESSION['role'] !== 'company') {
    header("Location: login.php");
    exit();
}

$company_id = $_SESSION['company']['id']; // ✅ Correct session variable

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = $_POST['productName'];
    $brand = $_POST['brand'];
    $price = $_POST['price'];
    $quantity = $_POST['quantity'];
    $category = $_POST['category'];
    $location = $_POST['location'];
    $description = $_POST['description'];

    // ✅ Handle image upload
    $imagePath = '';
    if (isset($_FILES['image']) && $_FILES['image']['error'] == 0) {
        $targetDir = "uploads/";
        if (!is_dir($targetDir)) mkdir($targetDir, 0777, true);
        $fileName = time() . "_" . basename($_FILES["image"]["name"]);
        $targetFile = $targetDir . $fileName;
        move_uploaded_file($_FILES["image"]["tmp_name"], $targetFile);
        $imagePath = $targetFile;
    }

    $sql = "INSERT INTO pending_products (company_id, productName, brand, price, quantity, category, location, image, description)
            VALUES ('$company_id', '$name', '$brand', '$price', '$quantity', '$category', '$location', '$imagePath', '$description')";
    if (mysqli_query($conn, $sql)) {
    echo "<script>alert('🕒 Product submitted for admin approval!'); window.location='../company_modal/company_dashboard.php';</script>";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Add Product | Glamour Beauty</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap" rel="stylesheet">

<style>
.btn-outline-pink {
  border: 2px solid #ff3ebf;
  color: #ff3ebf;
  border-radius: 25px;
  padding: 10px 25px;
  font-weight: 600;
  background: transparent;
  transition: 0.3s;
}

.btn-outline-pink:hover {
  background: linear-gradient(90deg, #ff3ebf, #ff69b4);
  color: white;
  transform: scale(1.05);
}

body {
  font-family: 'Poppins', sans-serif;
  background-color: #fff0f6;
}
.container {
  max-width: 600px;
  background: #fff;
  padding: 30px;
  margin-top: 40px;
  border-radius: 15px;
  box-shadow: 0 4px 15px rgba(255, 62, 191, 0.2);
}
.btn-pink {
  background: linear-gradient(90deg, #ff3ebf, #ff69b4);
  color: white;
  border-radius: 25px;
  padding: 10px 25px;
  border: none;
  font-weight: 600;
  transition: 0.3s;
}
.btn-pink:hover {
  background: #ff1493;
  transform: scale(1.05);
}
</style>
</head>
<body>
<div class="text-center mt-3">
  <a href="../company_modal/company_dashboard.php" class="btn btn-outline-pink">
    ⬅️ Back to Dashboard
  </a>
</div>

<div class="container">
  <h3 class="text-center mb-4" style="color:#ff3ebf;">💄 Add New Product</h3>
  <form method="POST" enctype="multipart/form-data">
    <div class="mb-3">
      <label>Product Name</label>
      <input type="text" name="productName" class="form-control" required>
    </div>
    <div class="mb-3">
      <label>Brand</label>
      <input type="text" name="brand" class="form-control" required>
    </div>
    <div class="mb-3">
      <label>Price (₱)</label>
      <input type="number" name="price" class="form-control" step="0.01" required>
    </div>
    <div class="mb-3">
      <label>Quantity</label>
      <input type="number" name="quantity" class="form-control" required>
    </div>
    <div class="mb-3">
      <label>Category</label>
      <select name="category" class="form-select" required>
        <option value="lipstick">Lipstick</option>
        <option value="foundation">Foundation</option>
        <option value="skincare">Skincare</option>
        <option value="accessories">Accessories</option>
      </select>
    </div>
    <div class="mb-3">
      <label>Location</label>
      <input type="text" name="location" class="form-control" required>
    </div>
    <div class="mb-3">
      <label>Description</label>
      <textarea name="description" class="form-control" rows="3"></textarea>
    </div>
    <div class="mb-3">
      <label>Product Image</label>
      <input type="file" name="image" class="form-control" accept="image/*" required>
    </div>

    <button type="submit" class="btn btn-pink w-100">Save Product</button>
    
  </form>
</div>

</body>
</html>