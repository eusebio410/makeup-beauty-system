<?php
session_start();
include '../includes/config.php';

if (!isset($_SESSION['company'])) {
    header("Location: ../auth/company_login.php");
    exit();
}

$company_id = $_SESSION['company']['id'];
$product_id = $_GET['id'] ?? 0;

// ✅ Check if the product belongs to the logged-in company
$check = mysqli_fetch_assoc(mysqli_query($conn, "SELECT * FROM products WHERE id='$product_id' AND company_id='$company_id'"));
if (!$check) {
    die("❌ Unauthorized access or product not found.");
}

// ✅ Delete the product
$delete = mysqli_query($conn, "DELETE FROM products WHERE id='$product_id' AND company_id='$company_id'");

if ($delete) {
    echo "<script>alert('✅ Product deleted successfully!'); window.location.href='../company_modal/company_dashboard.php';</script>";
} else {
    echo "<script>alert('❌ Failed to delete product.'); window.location.href='../company_modal/company_dashboard.php';</script>";
}
?>
