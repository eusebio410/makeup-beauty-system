<?php
session_start();
include '../includes/config.php';

// ✅ Ensure user is logged in
if (!isset($_SESSION['user'])) {
    header("Location: ../auth/login.php");
    exit();
}

$user = $_SESSION['user'];
$user_id = $user['id'] ?? null;
if (!$user_id) {
    die("❌ Invalid user session.");
}

$table = 'user_cart';

// ✅ Update quantity
if (isset($_POST['update_cart'])) {
    $cart_id = (int)$_POST['cart_id'];
    $new_qty = (int)$_POST['quantity'];

    if ($new_qty <= 0) {
        mysqli_query($conn, "DELETE FROM $table WHERE id='$cart_id'");
    } else {
        mysqli_query($conn, "UPDATE $table SET quantity='$new_qty' WHERE id='$cart_id'");
    }

    header("Location: user_cart.php");
    exit();
}

// ✅ Remove item
if (isset($_GET['remove'])) {
    $remove_id = (int)$_GET['remove'];
    mysqli_query($conn, "DELETE FROM $table WHERE id='$remove_id'");
    header("Location: user_cart.php");
    exit();
}

// ✅ Fetch cart items
$cartQuery = mysqli_query($conn, "SELECT * FROM $table WHERE user_id='$user_id'");
$total = 0;
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>🛒 Your Cart</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css" rel="stylesheet">
<style>
  body {
    background-color: #fff0f6;
    font-family: 'Poppins', sans-serif;
  }

  .cart-card {
    border-radius: 12px;
    background: #fff;
    box-shadow: 0 2px 8px rgba(0,0,0,0.1);
    padding: 15px;
    transition: transform 0.3s ease;
  }

  .cart-card:hover {
    transform: translateY(-5px);
  }

  .cart-img {
    width: 100%;
    height: 180px;
    object-fit: cover;
    border-radius: 10px;
    cursor: pointer;
  }

  .product-title {
    font-weight: 600;
    margin-top: 10px;
  }

  .price-tag {
    color: #e60073;
    font-weight: bold;
  }

  .discount-badge {
    background-color: #ffd6e7;
    color: #e60073;
    padding: 3px 7px;
    font-size: 12px;
    border-radius: 8px;
    margin-left: 5px;
  }

  .btn-edit { background-color: #ffc107; color: #000; border: none; }
  .btn-delete { background-color: #dc3545; color: #fff; border: none; }

  /* ✅ Modal for image view */
  #imageModal {
    display: none;
    position: fixed;
    z-index: 1050;
    padding-top: 60px;
    left: 0;
    top: 0;
    width: 100%;
    height: 100%;
    overflow: auto;
    background-color: rgba(0,0,0,0.8);
  }

  #imageModal img {
    display: block;
    margin: auto;
    max-width: 90%;
    max-height: 80%;
    border: 4px solid #fff;
    border-radius: 10px;
    animation: zoomIn 0.3s ease;
  }

  #imageModal .close {
    position: absolute;
    top: 20px;
    right: 35px;
    color: #fff;
    font-size: 40px;
    font-weight: bold;
    cursor: pointer;
  }

  @keyframes zoomIn {
    from {transform: scale(0.8); opacity: 0;}
    to {transform: scale(1); opacity: 1;}
  }

  /* ✅ Center Back to Home button */
  .back-home {
    display: flex;
    justify-content: center;
    margin-bottom: 30px;
  }
</style>
</head>
<body>

<div class="container mt-3 mb-5">
  <h2 class="mb-3 text-center">🛍️ Your Shopping Cart</h2>
  
  <div class="back-home">
    <a href="../user_modal/user_dashboard.php" class="btn btn-light">
      ⬅ Back to Home
    </a>
  </div>

  <?php if (mysqli_num_rows($cartQuery) > 0): ?>
    <div class="row g-4">
      <?php while ($item = mysqli_fetch_assoc($cartQuery)): ?>
        <?php 
          $subtotal = $item['price'] * $item['quantity']; 
          $total += $subtotal; 
        ?>
        <div class="col-md-3 col-sm-3">
          <div class="cart-card text-center p-3">
            <img src="../func/<?= htmlspecialchars($item['image']) ?>" 
                 alt="Product Image" 
                 class="cart-img"
                 onclick="openImageModal('../func/<?= htmlspecialchars($item['image']) ?>')">
            
            <h5 class="product-title mt-2"><?= htmlspecialchars($item['product_name']) ?></h5>
            <p class="price-tag">₱<?= number_format($item['price'], 2) ?> 
              <span class="discount-badge">-<?= rand(10,40) ?>%</span>
            </p>
            <p>Available: <?= $item['quantity'] ?></p>
            <p>Company: <?= htmlspecialchars($item['company_name'] ?? 'N/A') ?></p>

            <form method="POST" action="" class="mb-2">
              <input type="hidden" name="cart_id" value="<?= $item['id'] ?>">
              <input type="number" name="quantity" value="<?= $item['quantity'] ?>" 
                     min="1" class="form-control d-inline-block w-50 mb-2">
              <button type="submit" name="update_cart" class="btn btn-success btn-sm w-50">Update</button>
            </form>

            <p><strong>Subtotal:</strong> ₱<?= number_format($subtotal, 2) ?></p>
            <a href="user_cart.php?remove=<?= $item['id'] ?>" 
               class="btn btn-danger btn-sm w-100 mt-2">Remove</a>
          </div>
        </div>
      <?php endwhile; ?>
    </div>

    <div class="text-end mt-4">
      <h4>Total: ₱<?= number_format($total, 2) ?></h4>
      <a href="../func/checkout.php" class="btn btn-primary btn-lg mt-2">Proceed to Checkout</a>
    </div>

  <?php else: ?>
    <div class="alert alert-info text-center">Your cart is empty.</div>
  <?php endif; ?>
</div>

<!-- ✅ Image Modal -->
<div id="imageModal">
  <span class="close" onclick="closeImageModal()">&times;</span>
  <img id="modalImg" src="">
</div>

<script>
  function openImageModal(src) {
    document.getElementById("modalImg").src = src;
    document.getElementById("imageModal").style.display = "block";
  }

  function closeImageModal() {
    document.getElementById("imageModal").style.display = "none";
  }

  window.onclick = function(event) {
    const modal = document.getElementById('imageModal');
    if (event.target === modal) {
      modal.style.display = "none";
    }
  }
</script>

</body>
</html>
